#!/bin/bash
#
# This script is the interface to Q1 in this assignment submission.
# This script just runs Q1.
python3 Q1.py
# The name of the file can be upto you, arguments provided to it can also be
# upto you. Number of commands run in between can also be upto you. That's why
# there is this interface in between.
#
# DO NOT CHANGE DIRECTORY HERE. OR, IF YOU DO, MAKE SURE TO BRING BACK TO PWD
# AS THIS MIGHT BREAK AUTOMATIC EVALUATION OF SUBMISSION.
