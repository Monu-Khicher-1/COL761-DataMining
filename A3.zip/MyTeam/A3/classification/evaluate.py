import argparse
import os
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
from torch.nn import Linear
import torch.nn.functional as F
from torch_geometric.data import Data, Dataset, DataLoader
from torch_geometric.nn import GCNConv, SAGEConv
from torch_geometric.nn import global_mean_pool, global_max_pool
from sklearn.metrics import roc_auc_score
import matplotlib.pyplot as plt
import networkx as nx
import numpy as np


class CustomDataset(Dataset):
    def __init__(self, root, transform=None, pre_transform=None):
        super(CustomDataset, self).__init__(root, transform, pre_transform)
        self.data= torch.load(self.processed_paths[0])

    @property
    def raw_file_names(self):
        return ['graph_labels.csv.gz', 'num_nodes.csv.gz', 'num_edges.csv.gz',
                'node_features.csv.gz', 'edges.csv.gz', 'edge_features.csv.gz']

    @property
    def processed_file_names(self):
        return ['processed.pt']

    # def download(self):
    #     # Implement logic to download the dataset if needed
    #     pass

    def process(self):
        # Implement logic to process the raw data into PyTorch Geometric format
        dataset_name = os.path.basename(os.path.normpath(self.root))

        # Load data from CSV files
        graph_labels = pd.read_csv(os.path.join(self.root, 'graph_labels.csv.gz'), compression='gzip', header=None)
        num_nodes = pd.read_csv(os.path.join(self.root, 'num_nodes.csv.gz'), compression='gzip', header=None)
        num_edges = pd.read_csv(os.path.join(self.root, 'num_edges.csv.gz'), compression='gzip', header=None)
        node_features = pd.read_csv(os.path.join(self.root, 'node_features.csv.gz'), compression='gzip', header=None)
        edges = pd.read_csv(os.path.join(self.root, 'edges.csv.gz'), compression='gzip', header=None)
        edge_features = pd.read_csv(os.path.join(self.root, 'edge_features.csv.gz'), compression='gzip', header=None)

        # Process each graph in the dataset
        data_list = []
        for i in range(len(graph_labels)):
            if not np.isnan(graph_labels.iloc[i, 0]):
                label = torch.tensor(graph_labels.iloc[i, 0], dtype=torch.long)
            else:
                label = torch.tensor(np.random.randint(0, 2), dtype=torch.long)
            # convert nan to 0 or 1 randomly
            # if torch.isnan(label):
            if label!=0 and label!=1:
                label = torch.randint(0, 2, (1,))
            # print(label)
            num_node = torch.tensor(num_nodes.iloc[i, 0], dtype=torch.long)
            num_edge = torch.tensor(num_edges.iloc[i, 0], dtype=torch.long)

            # Extract node features for the current graph
            node_feat_start = sum(num_nodes.iloc[:i, 0])
            node_feat_end = node_feat_start + num_node
            x = torch.tensor(node_features.values[node_feat_start:node_feat_end], dtype=torch.float)

            # Extract edges for the current graph
            edge_start = sum(num_edges.iloc[:i, 0])
            edge_end = edge_start + num_edge
            edge_index = torch.tensor(edges.values[edge_start:edge_end], dtype=torch.long).t().contiguous()

            # Extract edge features for the current graph
            edge_feat_start = sum(num_edges.iloc[:i, 0])
            edge_feat_end = edge_feat_start + num_edge
            edge_attr = torch.tensor(edge_features.values[edge_feat_start:edge_feat_end], dtype=torch.float)

            data = Data(x=x, edge_index=edge_index, edge_attr=edge_attr, y=label)
            data_list.append(data)

        # Save processed data
        processed_path = os.path.join(self.root, 'processed', 'processed.pt')
        os.makedirs(os.path.dirname(processed_path), exist_ok=True)  # Create directories if they don't exist
        torch.save(data_list, processed_path)

    def len(self):
        return len(self.data)

    def get(self, idx):
        return self.data[idx]
    


class GraphClassifier(nn.Module):
    def __init__(self, num_node_features, num_classes):
        super(GraphClassifier, self).__init__()
        # Define GCN layers and softmax
        self.conv1 = GCNConv(num_node_features, 32)
        self.conv2 = GCNConv(32, 64)
        self.conv3 = GCNConv(64, 128)
        # linear
        self.linear = Linear(128, 1)
        # # softmax
        # self.softmax = nn.LogSoftmax(dim=1)
        self.sigmoid = nn.Sigmoid()
    def forward(self, x, edge_index, batch_index):
        # 1. Obtain node embeddings
        x = self.conv1(x, edge_index)
        # x = F.relu(x)
        x = nn.Tanh()(x)
        x = self.conv2(x, edge_index)
        # x = F.relu(x)
        x = nn.Tanh()(x)
        x = self.conv3(x, edge_index)
        # 2. Readout layer
        x = global_max_pool(x, batch_index)
        # 3. Apply a final classifier
        x = self.linear(x)
        # 4. Apply a softmax
        x = self.sigmoid(x)
        return x
    



def evaluate(model, loader, device):
    # Set model to evaluation mode
    model.eval()

    predictions = []
    targets = []

    # Do not need to calculate gradients
    with torch.no_grad():
        # Iterate over the test data and generate predictions
        for batch in loader:
            # Explicitly move the features and target to the device (CPU or GPU)
            batch.to(device)

            # Obtain the output
            out = model(batch.x, batch.edge_index, batch.batch)
            # for all elements in out, if > 0.25, then 1, else 0
            out = torch.where(out > 0.25, torch.tensor(1), torch.tensor(0))

            # Get predictions from the output
            # print(out)
            # pred = out.argmax(dim=1)
            pred = out.view(-1)
            # print(pred)

            # Append the batch predictions
            predictions.append(pred.detach().cpu())

            # Append the batch targets
            targets.append(batch.y.view(-1).detach().cpu())

    # Concatenate the predictions and the targets into a single tensor
    predictions = torch.cat(predictions)
    targets = torch.cat(targets)

    # Calculate accuracy score
    accuracy = torch.sum(predictions == targets) / len(targets)

    # Calculate AUC score
    auc = roc_auc_score(targets, predictions)

    return accuracy, auc



def main():
    parser = argparse.ArgumentParser(description="Evaluating the classification model")
    parser.add_argument("--model_path", required=True)
    parser.add_argument("--dataset_path", required=True)
    args = parser.parse_args()
    test_dataset = CustomDataset(root=args.dataset_path, transform=None, pre_transform=None)
    test_loader = DataLoader(test_dataset, batch_size=64, shuffle=True)

    # Set device to GPU or CPU
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    # Load model
    
    model = GraphClassifier(9,2)
    model.load_state_dict(torch.load("model_state_dict.pth"))
    model.eval()

    # Evaluate the model on the test dataset
    accuracy, auc = evaluate(model, test_loader, device)
    print(f"Accuracy: {accuracy:.4f}")
    print(f"AUC: {auc:.4f}")


    print(f"Evaluating the classification model. Model will be loaded from {args.model_path}. Test dataset will be loaded from {args.dataset_path}.")


if __name__=="__main__":
    main()


