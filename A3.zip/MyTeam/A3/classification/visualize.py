import os
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
from torch.nn import Linear
import torch.nn.functional as F
from torch_geometric.data import Data, Dataset, DataLoader
from torch_geometric.nn import GCNConv, SAGEConv
from torch_geometric.nn import global_mean_pool, global_max_pool
from sklearn.metrics import roc_auc_score
import matplotlib.pyplot as plt
import networkx as nx
import numpy as np
import networkx as nx


class GraphClassifier(nn.Module):
    def __init__(self, num_node_features, num_classes):
        super(GraphClassifier, self).__init__()
        # Define GCN layers and softmax
        self.conv1 = GCNConv(num_node_features, 32)
        self.conv2 = GCNConv(32, 64)
        self.conv3 = GCNConv(64, 128)
        # linear
        self.linear = Linear(128, 1)
        # # softmax
        # self.softmax = nn.LogSoftmax(dim=1)
        self.sigmoid = nn.Sigmoid()
    def forward(self, x, edge_index, batch_index):
        # 1. Obtain node embeddings
        x = self.conv1(x, edge_index)
        # x = F.relu(x)
        x = nn.Tanh()(x)
        x = self.conv2(x, edge_index)
        # x = F.relu(x)
        x = nn.Tanh()(x)
        x = self.conv3(x, edge_index)
        # 2. Readout layer
        x = global_max_pool(x, batch_index)
        # 3. Apply a final classifier
        x = self.linear(x)
        # 4. Apply a softmax
        x = self.sigmoid(x)
        return x


class CustomDataset(Dataset):
    def __init__(self, root, transform=None, pre_transform=None):
        super(CustomDataset, self).__init__(root, transform, pre_transform)
        self.data= torch.load(self.processed_paths[0])

    @property
    def raw_file_names(self):
        return ['graph_labels.csv.gz', 'num_nodes.csv.gz', 'num_edges.csv.gz',
                'node_features.csv.gz', 'edges.csv.gz', 'edge_features.csv.gz']

    @property
    def processed_file_names(self):
        return ['processed.pt']

    # def download(self):
    #     # Implement logic to download the dataset if needed
    #     pass

    def process(self):
        # Implement logic to process the raw data into PyTorch Geometric format
        dataset_name = os.path.basename(os.path.normpath(self.root))

        # Load data from CSV files
        graph_labels = pd.read_csv(os.path.join(self.root, 'graph_labels.csv.gz'), compression='gzip', header=None)
        num_nodes = pd.read_csv(os.path.join(self.root, 'num_nodes.csv.gz'), compression='gzip', header=None)
        num_edges = pd.read_csv(os.path.join(self.root, 'num_edges.csv.gz'), compression='gzip', header=None)
        node_features = pd.read_csv(os.path.join(self.root, 'node_features.csv.gz'), compression='gzip', header=None)
        edges = pd.read_csv(os.path.join(self.root, 'edges.csv.gz'), compression='gzip', header=None)
        edge_features = pd.read_csv(os.path.join(self.root, 'edge_features.csv.gz'), compression='gzip', header=None)

        # Process each graph in the dataset
        data_list = []
        for i in range(len(graph_labels)):
            if not np.isnan(graph_labels.iloc[i, 0]):
                label = torch.tensor(graph_labels.iloc[i, 0], dtype=torch.long)
            else:
                label = torch.tensor(np.random.randint(0, 2), dtype=torch.long)
            # convert nan to 0 or 1 randomly
            # if torch.isnan(label):
            if label!=0 and label!=1:
                label = torch.randint(0, 2, (1,))
            # print(label)
            num_node = torch.tensor(num_nodes.iloc[i, 0], dtype=torch.long)
            num_edge = torch.tensor(num_edges.iloc[i, 0], dtype=torch.long)

            # Extract node features for the current graph
            node_feat_start = sum(num_nodes.iloc[:i, 0])
            node_feat_end = node_feat_start + num_node
            x = torch.tensor(node_features.values[node_feat_start:node_feat_end], dtype=torch.float)

            # Extract edges for the current graph
            edge_start = sum(num_edges.iloc[:i, 0])
            edge_end = edge_start + num_edge
            edge_index = torch.tensor(edges.values[edge_start:edge_end], dtype=torch.long).t().contiguous()

            # Extract edge features for the current graph
            edge_feat_start = sum(num_edges.iloc[:i, 0])
            edge_feat_end = edge_feat_start + num_edge
            edge_attr = torch.tensor(edge_features.values[edge_feat_start:edge_feat_end], dtype=torch.float)

            data = Data(x=x, edge_index=edge_index, edge_attr=edge_attr, y=label)
            data_list.append(data)

        # Save processed data
        processed_path = os.path.join(self.root, 'processed', 'processed.pt')
        os.makedirs(os.path.dirname(processed_path), exist_ok=True)  # Create directories if they don't exist
        torch.save(data_list, processed_path)

    def len(self):
        return len(self.data)

    def get(self, idx):
        return self.data[idx]
    



# Load the model
model_path = 'model1.pt'  # Update this path
model = GraphClassifier(9,2)
model.load_state_dict(torch.load(model_path))
# model.eval()

# Initialize the dataset
dataset_root = 'valid'  # Update with the path to your dataset
dataset = CustomDataset(root=dataset_root)
loader = DataLoader(dataset, batch_size=1, shuffle=False)

# Evaluate the model and collect misclassified graphs
graphs_index = []
misclassified_graphs = []
count = 0
for data in loader:
    with torch.no_grad():
        output = model(data.x, data.edge_index, data.batch)
        prediction = (output > 0.5).float()
        count+=1
        if prediction != data.y:
            graphs_index.append(count)
            misclassified_graphs.append((data, prediction, data.y))

# Function to visualize a graph using NetworkX
def visualize_graph(data, prediction, true_label,index):
    G = nx.Graph()
    edge_index = data.edge_index.numpy()
    edges = zip(edge_index[0], edge_index[1])
    G.add_edges_from(edges)
    plt.figure(figsize=(8, 6))
    nx.draw(G, with_labels=True, node_color='lightblue', node_size=500, edge_color='gray')
    plt.title(f'{index}Predicted: {prediction.item()}, True Label: {true_label.item()}')
    plt.show()

# Visualize misclassified graphs
i=0
for data, prediction, true_label in misclassified_graphs:
    index = graphs_index[i]
    visualize_graph(data, prediction, true_label,index)
    i+=1
