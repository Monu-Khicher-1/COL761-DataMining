import os
import pandas as pd
import numpy as np
import networkx as nx
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import sys
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import networkx as nx


def load_data(path):
    graph_labels = pd.read_csv(f'{path}/graph_labels.csv.gz', header=None, names=['Label'])
    num_nodes = pd.read_csv(f'{path}/num_nodes.csv.gz', header=None, names=['Num_Nodes'])
    num_edges = pd.read_csv(f'{path}/num_edges.csv.gz', header=None, names=['Num_Edges'])
    node_features = pd.read_csv(f'{path}/node_features.csv.gz', header=None)
    edges = pd.read_csv(f'{path}/edges.csv.gz', header=None, names=['Node1', 'Node2'])
    edge_features = pd.read_csv(f'{path}/edge_features.csv.gz', header=None)
    return graph_labels, num_nodes, num_edges, node_features, edges, edge_features

# Function to plot the distribution of graph labels
def plot_graph_labels(graph_labels):
    plt.figure(figsize=(10, 6))
    sns.countplot(x='Label', data=graph_labels)
    plt.title('Distribution of Graph Labels')
    plt.xlabel('Graph Label')
    plt.ylabel('Count')
    plt.grid(axis='y')
    plt.show()

# Function to plot the distribution of number of nodes and edges
def plot_nodes_edges_distribution(num_nodes, num_edges):
    plt.figure(figsize=(12, 6))
    plt.subplot(1, 2, 1)
    sns.histplot(num_nodes['Num_Nodes'], kde=True, bins=30)
    plt.title('Distribution of Number of Nodes')
    plt.xlabel('Number of Nodes')
    plt.ylabel('Count')

    plt.subplot(1, 2, 2)
    sns.histplot(num_edges['Num_Edges'], kde=True, bins=30)
    plt.title('Distribution of Number of Edges')
    plt.xlabel('Number of Edges')
    plt.ylabel('Count')

    plt.tight_layout()
    plt.show()

# Function to plot sample graphs
def plot_sample_graphs(edges, num_nodes, num_edges, num_graphs=3):
    start_idx = 0
    for i in range(num_graphs):
        n_nodes = num_nodes.iloc[i]['Num_Nodes']
        n_edges = num_edges.iloc[i]['Num_Edges']

        end_idx = start_idx + n_edges
        graph_edges = edges.iloc[start_idx:end_idx]
        start_idx = end_idx

        G = nx.Graph()
        for _, row in graph_edges.iterrows():
            G.add_edge(row['Node1'], row['Node2'])

        plt.figure(figsize=(6, 4))
        nx.draw(G, with_labels=True, node_color='lightblue', font_weight='bold', node_size=700)
        plt.title(f'Sample Graph {i+1} (Nodes: {n_nodes}, Edges: {n_edges})')
        plt.show()

# Function to plot feature distributions
def plot_feature_distributions(node_features, edge_features):
    plt.figure(figsize=(12, 10))
    for i in range(3):
        plt.subplot(3, 2, 2*i + 1)
        sns.histplot(node_features[i], kde=True, bins=30)
        plt.title(f'Distribution of Node Feature {i+1}')
        plt.xlabel(f'Feature {i+1} Value')
        plt.ylabel('Count')

        plt.subplot(3, 2, 2*i + 2)
        sns.histplot(edge_features[i], kde=True, bins=30)
        plt.title(f'Distribution of Edge Feature {i+1}')
        plt.xlabel(f'Feature {i+1} Value')
        plt.ylabel('Count')

    plt.tight_layout()
    plt.show()

# Main function to run the analysis
def main():
    path = sys.argv[1]
    graph_labels, num_nodes, num_edges, node_features, edges, edge_features = load_data(path)
    plot_graph_labels(graph_labels)
    plot_nodes_edges_distribution(num_nodes, num_edges)
    plot_sample_graphs(edges, num_nodes, num_edges)
    plot_feature_distributions(node_features, edge_features)

if __name__ == "__main__":
    main()