import numpy as np
import matplotlib.pyplot as plt

# ==================================================================
# Helping Functions
# ===================================================================

def generate_points(dimension, num_points=1000000):
    return np.random.uniform(0, 1, (num_points, dimension))

def compute_distances(query_point, data_points):
    query_point_expanded = np.tile(query_point, (data_points.shape[0], 1))
    differences = data_points - query_point_expanded
    
    l1_distances = np.sum(np.abs(differences), axis=1)
    l2_distances = np.sqrt(np.sum(np.square(differences), axis=1))
    linf_distances = np.max(np.abs(differences), axis=1)
    
    return l1_distances, l2_distances, linf_distances

def average_ratio(distances):
    min_distance = np.min(distances)
    max_distance = np.max(distances)
    return max_distance / min_distance if min_distance > 0 else np.inf

# ==================================================================
# Main Code 
# ===================================================================


dimensions = [1, 2, 4, 8, 16, 32, 64]
num_query_points = 100


avg_ratios_l1 = []
avg_ratios_l2 = []
avg_ratios_linf = []


for d in dimensions:
    # Generate data points and query points...
    data_points = generate_points(d)
    query_indices = np.random.choice(data_points.shape[0], num_query_points, replace=False)
    query_points = data_points[query_indices]
    
    # Compute distances 
    data_points = np.delete(data_points, query_indices, axis=0)
    
    max_min_ratios_l1 = []
    max_min_ratios_l2 = []
    max_min_ratios_linf = []
    
    for query_point in query_points:
        l1, l2, linf = compute_distances(query_point, data_points)
        
        max_min_ratios_l1.append(average_ratio(l1))
        max_min_ratios_l2.append(average_ratio(l2))
        max_min_ratios_linf.append(average_ratio(linf))
    
    # Append the average of max/min ratios for each dimension
    avg_ratios_l1.append(np.mean(max_min_ratios_l1))
    avg_ratios_l2.append(np.mean(max_min_ratios_l2))
    avg_ratios_linf.append(np.mean(max_min_ratios_linf))

# Plot the results
plt.plot(dimensions, avg_ratios_l1, 'o-', label='L1')
plt.plot(dimensions, avg_ratios_l2, 's-', label='L2')
plt.plot(dimensions, avg_ratios_linf, 'd-', label='L∞')
plt.xlabel('Dimension (d)')
plt.ylabel('Average Ratio of Farthest to Nearest Distance')
plt.title('Average Distance Ratio vs Dimension')
plt.legend()
plt.xscale('log')
plt.yscale('log')
plt.grid(True)
plt.show()