
# Folder Format

* For visualization part all codes are written in visualize.py.
* We trained our model over GPU on Google Colab. 
* data_analysis.py : It takes dataset folder path as input and plots visualiztion of dataset.

