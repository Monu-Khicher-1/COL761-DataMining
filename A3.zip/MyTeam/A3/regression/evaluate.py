import argparse
import os
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
from torch.nn import Linear
import torch.nn.functional as F
from torch_geometric.data import Data, Dataset, DataLoader
from torch_geometric.nn import GCNConv
from torch_geometric.nn import global_mean_pool
from sklearn.metrics import roc_auc_score
import matplotlib.pyplot as plt
import networkx as nx
import numpy as np



class CustomDataset(Dataset):
    def __init__(self, root, transform=None, pre_transform=None):
        super(CustomDataset, self).__init__(root, transform, pre_transform)
        self.data= torch.load(self.processed_paths[0])

    @property
    def raw_file_names(self):
        return ['graph_labels.csv.gz', 'num_nodes.csv.gz', 'num_edges.csv.gz',
                'node_features.csv.gz', 'edges.csv.gz', 'edge_features.csv.gz']

    @property
    def processed_file_names(self):
        return ['processed.pt']

    # def download(self):
    #     # Implement logic to download the dataset if needed
    #     pass

    def process(self):
        # Implement logic to process the raw data into PyTorch Geometric format
        dataset_name = os.path.basename(os.path.normpath(self.root))

        # Load data from CSV files
        graph_labels = pd.read_csv(os.path.join(self.root, 'graph_labels.csv.gz'), compression='gzip', header=None)
        num_nodes = pd.read_csv(os.path.join(self.root, 'num_nodes.csv.gz'), compression='gzip', header=None)
        num_edges = pd.read_csv(os.path.join(self.root, 'num_edges.csv.gz'), compression='gzip', header=None)
        node_features = pd.read_csv(os.path.join(self.root, 'node_features.csv.gz'), compression='gzip', header=None)
        edges = pd.read_csv(os.path.join(self.root, 'edges.csv.gz'), compression='gzip', header=None)
        edge_features = pd.read_csv(os.path.join(self.root, 'edge_features.csv.gz'), compression='gzip', header=None)

        # Process each graph in the dataset
        data_list = []
        for i in range(len(graph_labels)):
            # if not np.isnan(graph_labels.iloc[i, 0]):
            label = torch.tensor(graph_labels.iloc[i, 0], dtype=torch.float)
            # else:
            #     label = torch.tensor(np.random.randint(0, 2), dtype=torch.long)
            # convert nan to 0 or 1 randomly
            # if torch.isnan(label):
            if label!=0 and label!=1:
                label = torch.randint(0, 2, (1,))
            # print(label)
            num_node = torch.tensor(num_nodes.iloc[i, 0], dtype=torch.long)
            num_edge = torch.tensor(num_edges.iloc[i, 0], dtype=torch.long)

            # Extract node features for the current graph
            node_feat_start = sum(num_nodes.iloc[:i, 0])
            node_feat_end = node_feat_start + num_node
            x = torch.tensor(node_features.values[node_feat_start:node_feat_end], dtype=torch.float)

            # Extract edges for the current graph
            edge_start = sum(num_edges.iloc[:i, 0])
            edge_end = edge_start + num_edge
            edge_index = torch.tensor(edges.values[edge_start:edge_end], dtype=torch.long).t().contiguous()

            # Extract edge features for the current graph
            edge_feat_start = sum(num_edges.iloc[:i, 0])
            edge_feat_end = edge_feat_start + num_edge
            edge_attr = torch.tensor(edge_features.values[edge_feat_start:edge_feat_end], dtype=torch.float)

            data = Data(x=x, edge_index=edge_index, edge_attr=edge_attr, y=label)
            data_list.append(data)

        # Save processed data
        processed_path = os.path.join(self.root, 'processed', 'processed.pt')
        os.makedirs(os.path.dirname(processed_path), exist_ok=True)  # Create directories if they don't exist
        torch.save(data_list, processed_path)

    def len(self):
        return len(self.data)

    def get(self, idx):
        return self.data[idx]


class Net(torch.nn.Module):
    def __init__(self, num_node_features):
        super(Net, self).__init__()
        self.conv1 = GCNConv(num_node_features, 32)
        self.conv2 = GCNConv(32, 64)
        self.conv3 = GCNConv(64, 128)
        self.conv4 = GCNConv(128, 256)
        self.lin1 = Linear(256, 64)
        self.lin2 = Linear(64, 1)
    def forward(self, x, edge_index, batch):
        # 1. Obtain node embeddings
        x = self.conv1(x, edge_index)
        x = F.relu(x)
        x = self.conv2(x, edge_index)
        x = F.relu(x)
        x = self.conv3(x, edge_index)
        x = F.relu(x)
        x = self.conv4(x, edge_index)
        # 2. Readout layer
        x = global_mean_pool(x, batch)
        # linear layer
        x = self.lin1(x)
        x = F.relu(x)
        x = self.lin2(x)
        return x



def evaluate(model, loader, device):
    # Set model to evaluation mode
    model.eval()

    predictions = []
    targets = []
    # Don't need to keep track of gradients
    with torch.no_grad():
        # Iterate over the test data and generate predictions
        for batch in loader:
            # Explicitly move the features to the device (CPU or GPU)
            batch.to(device)

            # Forward pass to obtain node embeddings
            out = model(batch.x, batch.edge_index, batch.batch)

            # Convert node embeddings to predictions
            pred = out.view(-1).detach().cpu().numpy()
            predictions.append(pred)
            targets.append(batch.y.view(-1).detach().cpu().numpy())

    predictions = np.concatenate(predictions, axis=0)
    targets = np.concatenate(targets, axis=0)
    rmse = np.sqrt(np.mean((predictions - targets) ** 2))
    return rmse 



def main():
    parser = argparse.ArgumentParser(description="Evaluating the regression model")
    parser.add_argument("--model_path", required=True)
    parser.add_argument("--dataset_path", required=True)
    args = parser.parse_args()
    print(f"Evaluating the regression model. Model will be loaded from {args.model_path}. Test dataset will be loaded from {args.dataset_path}.")

    # Load model
    model_path = args.model_path
    model = Net()
    model.load_state_dict(torch.load(model_path))

    # Load test dataset
    test_dataset = CustomDataset(root=args.val_dataset_path, transform=None, pre_transform=None)
    test_loader = DataLoader(test_dataset, batch_size=32, shuffle=False)

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model.to(device)
    rmse = evaluate(model, test_loader, device)
    print(f"RMSE: {rmse}")




if __name__=="__main__":
    main()
