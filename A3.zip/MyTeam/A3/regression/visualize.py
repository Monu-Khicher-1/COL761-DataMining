import os
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
from torch.nn import Linear
import torch.nn.functional as F
from torch_geometric.data import Data, Dataset, DataLoader
from torch_geometric.nn import GCNConv, SAGEConv
from torch_geometric.nn import global_mean_pool, global_max_pool
from sklearn.metrics import roc_auc_score
import matplotlib.pyplot as plt
import networkx as nx
import numpy as np
import networkx as nx

class Net(torch.nn.Module):
    def __init__(self, num_node_features):
        super(Net, self).__init__()
        self.conv1 = GCNConv(num_node_features, 32)
        self.conv2 = GCNConv(32, 64)
        self.conv3 = GCNConv(64, 128)
        self.conv4 = GCNConv(128, 256)
        self.lin1 = Linear(256, 64)
        self.lin2 = Linear(64, 1)
    def forward(self, x, edge_index, batch):
        # 1. Obtain node embeddings
        x = self.conv1(x, edge_index)
        x = F.relu(x)
        x = self.conv2(x, edge_index)
        x = F.relu(x)
        x = self.conv3(x, edge_index)
        x = F.relu(x)
        x = self.conv4(x, edge_index)
        # 2. Readout layer
        x = global_mean_pool(x, batch)
        # linear layer
        x = self.lin1(x)
        x = F.relu(x)
        x = self.lin2(x)
        return x
    
def main():
    
    model_path = 'model.pt'  # Update this path
    model = Net(9)
    model.load_state_dict(torch.load(model_path))


    # Update this path
    val_path = '/content/drive/MyDrive/Data/Data_mining/dataset/dataset_1/valid'

    # Load data from CSV files



    graph_labels_path =  f'{val_path}/graph_labels.csv.gz'
    num_nodes_path = f'{val_path}/num_nodes.csv.gz'
    num_edges_path = f'{val_path}/num_edges.csv.gz'
    node_features_path =  f'{val_path}/node_features.csv.gz'
    edges_path =  f'{val_path}/edges.csv.gz'
    edge_features_path = f'{val_path}/edge_features.csv.gz'

    # Load data from CSV files
    graph_labels = pd.read_csv(graph_labels_path, compression='gzip', header=None)
    num_nodes = pd.read_csv(num_nodes_path, compression='gzip', header=None)
    num_edges = pd.read_csv(num_edges_path, compression='gzip', header=None)
    node_features = pd.read_csv(node_features_path, compression='gzip', header=None)
    edges = pd.read_csv(edges_path, compression='gzip', header=None)
    edge_features = pd.read_csv(edge_features_path, compression='gzip', header=None)

    # Process each graph in the dataset
    data_list = []
    for i in range(len(graph_labels)):
        label = torch.tensor([graph_labels.iloc[i, 0]], dtype=torch.float)
        
        num_node = int(num_nodes.iloc[i, 0])
        num_edge = int(num_edges.iloc[i, 0])

        node_feat_start = sum(num_nodes.iloc[:i, 0])
        node_feat_end = node_feat_start + num_node
        x = torch.tensor(node_features.values[node_feat_start:node_feat_end], dtype=torch.float)

        edge_start = sum(num_edges.iloc[:i, 0])
        edge_end = edge_start + num_edge
        edge_index = torch.tensor(edges.values[edge_start:edge_end], dtype=torch.long).t().contiguous()

        edge_feat_start = sum(num_edges.iloc[:i, 0])
        edge_feat_end = edge_feat_start + num_edge
        edge_attr = torch.tensor(edge_features.values[edge_feat_start:edge_feat_end], dtype=torch.float)

        data = Data(x=x, edge_index=edge_index, edge_attr=edge_attr, y=label)
        data_list.append(data)



    # DataLoader
    loader = DataLoader(data_list, batch_size=1, shuffle=False)

    # Prediction and Evaluation
    predictions = []
    true_labels = []
    for data in loader:
        with torch.no_grad():
            output = model(data.x, data.edge_index, data.batch)
        predictions.append(output.item())
        true_labels.append(data.y.item())

    # Calculate mean squared error
    mse = np.mean((np.array(predictions) - np.array(true_labels)) ** 2)
    print("Mean Squared Error:", mse)

    # Visualize significant errors
    error_threshold = 0.5  # Set your error threshold
    significant_errors = [(i, p, t) for i, (p, t) in enumerate(zip(predictions, true_labels)) if abs(p - t) > error_threshold]

    # Visualize the first few graphs with significant errors
    for i, pred, true in significant_errors[:5]:  # Adjust the range as needed
        data = data_list[i]
        G = nx.Graph()
        edge_index = data.edge_index.numpy()
        edges = zip(edge_index[0], edge_index[1])
        G.add_edges_from(edges)
        
        plt.figure(figsize=(10, 5))
        plt.title(f"Graph {i} - Prediction: {pred:.2f}, True Label: {true}")
        nx.draw(G, with_labels=True, node_color='lightblue', node_size=500, edge_color='gray')
        plt.show()

