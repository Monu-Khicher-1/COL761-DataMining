import numpy as np
import matplotlib.pyplot as plt
import sys
from sklearn.cluster import KMeans
from sklearn import metrics
from scipy.spatial.distance import cdist

def elbow_plot(dataset, dimension, plot_name):
    X = np.loadtxt(dataset)   
    distortions = []
    K = range(1,16)
    for k in K:
        kmeanModel = KMeans(n_clusters=k, n_init=10).fit(X)
        kmeanModel.fit(X)
        distortions.append(sum(np.min(cdist(X, kmeanModel.cluster_centers_, 'euclidean'), axis=1)) / X.shape[0])
    plt.plot(K, distortions, 'bx-')
    plt.xlabel('k')
    plt.ylabel('Distortion')
    plt.title('The Elbow Method showing the optimal k')
    plt.savefig(plot_name)


if __name__ == "__main__":
    dataset = sys.argv[1]
    dimension = sys.argv[2]
    plot_name = sys.argv[3]
    elbow_plot(dataset, dimension, plot_name)