#!/bin/bash

if [ "$#" -ne 3 ]; then
    echo "Usage: $0 <dataset> <dimension> <output_file>"
    exit 1
fi

# Assign the provided arguments to variables
dataset="$1"
dimension="$2"
output_file="$3"

python elbow_plot.py "$dataset" "$dimension" "$output_file"
