Question 1:

Run the following commands:
1. cd Q1                             => to enter into the directory
2. $ bash compile.sh                 => to compile all files
3. $ bash plot.sh <data_file_name>   => to get final results 

Finally you get time data for each support value.

Question 2:

Run the following commands:
1. cd Q2
2. sh elbow_plot.sh <dataset> <dimension> q3_<dimension>_<RollNo>.png

Question 3:

Answer is in the report named CS5200432.pdf present in the current directory

Team Members:
1. Monu (2020CS520432)
2. Earavelly Sriharshitha (2020CS10345)
3. Bolem Venkata Sai Surya Vidya Charan (2020CS10334)

Contribution:
Everyone in the team has contributed equally.