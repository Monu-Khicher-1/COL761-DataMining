

./convert_data 1 $1 gspan.txt
./convert_data 2 $1 fsg.txt
./convert_data 3 $1 gaston.txt

./plot gaston.txt fsg.txt gaston.txt 