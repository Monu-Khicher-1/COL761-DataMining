#include <bits/stdc++.h>
using namespace std;

int main(int argc, char* argv[]){
    int type = atoi(argv[1]);
    string input_file = argv[2];
    string output_file = argv[3];

    if(type==1 ){
        int gcount=0;
        ifstream fin(input_file);
        ofstream fout(output_file);
        string line;
        while(getline(fin, line)){
            if(line[0]=='#'){
                gcount++;
                int id = gcount;
                fout<<"t # "<<id<< endl; 
                getline(fin, line);
                int vcount=0;
                int v = atoi(line.c_str());
                unordered_map<string,int> vmap;
                for(int i=0;i<v;i++){
                    getline(fin, line);
                    if(vmap.find(line)==vmap.end()){
                        vmap[line]=vcount;
                        vcount++;
                    }
                    fout<<"v "<<to_string(i)<<" "<<vmap[line]<<endl;
                }
                getline(fin, line);
                int e = atoi(line.c_str());
                for(int i=0;i<e;i++){
                    getline(fin, line);
                    fout<<"e "<<line<<endl;
                }
            }
        }
        fin.close();
        fout.close();
    }
    else if(type==3 ){
        int gcount=0;
        ifstream fin(input_file);
        ofstream fout(output_file);
        string line;
        while(getline(fin, line)){
            if(line[0]=='#'){
                gcount++;
                int id = gcount;
                fout<<"t # "<<id<< endl; 
                getline(fin, line);
                int v = atoi(line.c_str());
                int vcount=0;
                unordered_map<string,int> vmap;
                for(int i=0;i<v;i++){
                    getline(fin, line);
                    if(vmap.find(line)==vmap.end()){
                        vmap[line]=vcount;
                        vcount++;
                    }
                    fout<<"v "<<to_string(i)<<" "<<vmap[line]<<endl;
                }
                getline(fin, line);
                int e = atoi(line.c_str());
                for(int i=0;i<e;i++){
                    getline(fin, line);
                    fout<<"e "<<line<<endl;
                }
            }
        }
        fin.close();
        fout.close();
    }
    else {
        ifstream fin(input_file);
        ofstream fout(output_file);
        string line;
        while(getline(fin, line)){
            if(line[0]=='#'){
                fout<<"t"<< endl; 
                getline(fin, line);
                int v = atoi(line.c_str());
                for(int i=0;i<v;i++){
                    getline(fin, line);
                    fout<<"v "<<to_string(i)<<" "<<line<<endl;
                }
                getline(fin, line);
                int e = atoi(line.c_str());
                for(int i=0;i<e;i++){
                    getline(fin, line);
                    fout<<"u "<<line<<endl;
                }
            }
        }
        fin.close();
        fout.close();
    }
    return 0;
}
