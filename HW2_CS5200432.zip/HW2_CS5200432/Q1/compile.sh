g++ convert_data.cpp -o convert_data
g++ plot.cpp -o plot