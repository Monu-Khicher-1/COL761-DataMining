#!/bin/sh
#Set the job name (for your reference)
#PBS -N test
### Set the project name, your department code by default
#PBS -P col761
### Request email when job begins and ends
#PBS -m bea
### Specify email address to use for notification.
#PBS -M $cs1200345@iitd.ac.in
### chunk specific resources ###(select=5:ncpus=4:mpiprocs=4:ngpus=2:mem=2GB::centos=skylake etc.)
#PBS -l select=4:ncpus=4:mpiprocs=2:centos=haswell
### Specify "wallclock time" required for this job, hhh:mm:ss
#PBS -l walltime=5:30:00
#PBS -l software=INTEL_PARALLEL_STUDIO


## Keep single # before PBS to consider it as command ,
## more than one # before PBS considered as comment.
## any command/statement other than PBS starting with # is considered as comment.
## Please comment/uncomment the portion as per your requirement before submitting job



#Environment Setup
echo "==============================="
echo $PBS_JOBID
cd $PBS_O_WORKDIR

#job execution command
g++ convert_data.cpp -o convert_data
g++ plot.cpp -o plot