#include <bits/stdc++.h>
using namespace std;

int main(int argc, char *argv[])
{
    string file_gspan = argv[1];
    string file_fsg = argv[2];
    string file_gaston = argv[3];
    vector<float> minSup = {5, 10, 25, 50, 95};
    vector<string> fout_name = {"minsup_0.05", "minsup_0.10", "minsup_0.25", "minsup_0.50", "minsup_0.95"};
    vector<string> algos = {"gspan", "fsg", "gaston"};
    unordered_map<string, vector<float>> time;
    time["gspan"] = {};
    time["fsg"] = {};
    time["gaston"] = {};
    for (int i = 0; i < minSup.size(); i++)
    {
        float sup = minSup[i];
        for (string algo : algos)
        {
            string command;
            if (algo == "gspan")
            {
                command = "./gSpan -f " + file_gspan + " -s " + to_string(sup / 100) + " -o -i";
            }
            else if (algo == "fsg")
            {
                command = "./fsg -s " + to_string(sup) + " " + file_fsg;
            }
            else
            {
                command = "./gaston " + to_string(sup * 641.10) + " " + file_gaston;
            }

            auto start = std::chrono::high_resolution_clock::now();

            system(command.c_str());

            auto stop = std::chrono::high_resolution_clock::now();
            auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(stop - start);
            float time_taken = duration.count() / 1000.0;
            time[algo].push_back(time_taken);
        }
    }
    for (string algo : algos)
    {
        cout << algo << ": ";
        for (int i = 0; i < minSup.size(); i++)
        {
            cout << time[algo][i] << " ";
        }
        cout << endl;
    }
}