
Run following commands:
1. $ bash compile.sh   => to compile all files
2. $ bash plot.sh <data_file_name>   => to get final results 

finally you get time data for each support value.
